months = int(input("Your Age In Months:"))

years = months/12 
print ("You are", years, "Years Old")