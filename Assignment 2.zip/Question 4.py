import math

h = int(input("Enter Height Of PolyTank:"))
r = int(input("Enter Radius Of PolyTank:"))

Poly_volume = math.pi * r**2 * h
print("Volume Of Cylinder is", Poly_volume)