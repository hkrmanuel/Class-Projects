total_choco = 213
total_students = 133
chocolate_per_student =213//133
remaining_chocolate = 213 % 133
print("Each student got", chocolate_per_student )
print("The remaining chocolate is", remaining_chocolate)
