import math
r = 2.5
h = 4
sphere_volume = 1/3 * math.pi * r**2 *h
print("The Volume Of The Cone is", sphere_volume)
