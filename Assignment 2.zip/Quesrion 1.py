old_sem = 62
new_sem = 133

percent_increase = (new_sem - old_sem)/old_sem * 100

print(percent_increase)