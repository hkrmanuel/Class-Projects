def count_digits(dig):
    length = len(str(dig))
    print("THe number", dig, "has", length, "digits")

dig = input("Enter Number:")
count_digits(dig)