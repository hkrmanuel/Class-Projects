
def greeting(name, age):
    print("Hello",  name +".", "You're", age)

name = input("What is Your name:")
age = input("How old are you?:")
greeting(name, age)