myList = []
myList.append(76)
myList.append(92.3)
myList.append("hello")
myList += [True]
myList += [4]
myList += [76]  

print(myList)
    