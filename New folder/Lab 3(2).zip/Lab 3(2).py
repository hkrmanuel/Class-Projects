x = int(input("Enter Number:"))

if x % 2 == 0:
    print('This Is an Even Nunber')
else:
    print ('this is a Odd number')