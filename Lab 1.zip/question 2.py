import time
datetime = time.asctime()
print(datetime) 
